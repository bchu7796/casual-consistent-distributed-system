#include <iostream>
#include <stdio.h>
#include <map>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <sys/time.h>
#include <unistd.h>
#include <string>
#include <vector>
#include "server.hpp"

int main(void){
    server datacenter(1002, "127.0.0.1", 8082);
    datacenter.listen_client();
}
